package com.gamya;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CreateServlet1
 */
@WebServlet("/CreateServlet1")
public class CreateServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	   response.setContentType("text/html");  
       PrintWriter out=response.getWriter();  
  
       String name=request.getParameter("name");      
       int age=Integer.parseInt(request.getParameter("age"));  
       int salary=Integer.parseInt(request.getParameter("salary"));  
       String designation=request.getParameter("designation");  
         
       Emp1 e=new Emp1();  
       
       e.setName(name);  
       e.setAge(age);  
       e.setSalary(salary);  
       e.setDesignation(designation);  
         
       int status=EmpDao1.save(e);  
       if(status>0){  
           out.print("<p>saved successfully!</p>");  
           request.getRequestDispatcher("index.html").include(request, response);  
       }else{  
           out.println("Sorry! unable to save record");  
       }  
         
       out.close();  
   }  
 
}  


   

	


