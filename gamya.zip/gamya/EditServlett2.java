package com.gamya;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EditServlett2
 */
@WebServlet("/EditServlett2")
public class EditServlett2 extends HttpServlet {
protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {  
	        response.setContentType("text/html");  
	        PrintWriter out=response.getWriter();  
	          
	        String sid=request.getParameter("id");  
	        int id=Integer.parseInt(sid);  
	        String name=request.getParameter("name");  
	        int age=Integer.parseInt(request.getParameter("age"));  
	        int salary=Integer.parseInt(request.getParameter("email"));  
	        String designation=request.getParameter("designation");  
	          
	        Emp1 e=new Emp1();  
	        e.setId(id);  
	        e.setName(name);  
	        e.setAge(age);  
	        e.setSalary(salary);  
	        e.setDesignation(designation);  
	          
	        int status=EmpDao1.update(e);  
	        if(status>0){  
	            response.sendRedirect("ViewServlet");  
	        }else{  
	            out.println("Sorry! unable to update record");  
	        }  
	          
	        out.close(); 
     }
}
	    