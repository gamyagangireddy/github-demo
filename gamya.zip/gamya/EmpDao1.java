package com.gamya;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


import javax.servlet.annotation.WebServlet;


/**
 * Servlet implementation class EmpDao1
 */
@WebServlet("/EmpDao1")
public class EmpDao1  {
	public static Connection getConnection(){  
        Connection con=null;  
        try{  
            Class.forName("com.mysql.jdbc.driver");  
            con=DriverManager.getConnection("jdbc:mysql://localhost/mydb","root","Gamya@123");  
        }catch(Exception e){System.out.println(e);}  
        return con;  
    }  
    public static int save(Emp1 e){  
        int status=0;  
        try{  
            Connection con=EmpDao1.getConnection();  
            PreparedStatement ps=con.prepareStatement(  
                         "insert into user905(name,age,salary,designation) values (?,?,?,?)");  
            ps.setString(1,e.getName());  
            ps.setInt(2,e.getAge());  
            ps.setInt(3,e.getSalary());  
            ps.setString(4,e.getDesignation());  
              
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return status;  
    }  
    public static int update(Emp1 e){  
        int status=0;  
        try{  
            Connection con=EmpDao1.getConnection();  
            PreparedStatement ps=con.prepareStatement(  
                         "update user905 set name=?,age=?,salary=?,designation=? where id=?");  
           
            ps.setString(1,e.getName());
            ps.setInt(2,e.getAge());  
            ps.setInt(3,e.getSalary());  
            ps.setString(4,e.getDesignation());  
            ps.setInt(5,e.getId());  
              
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return status;  
    }  
    public static int delete(int id){  
        int status=0;  
        try{  
            Connection con=EmpDao1.getConnection();  
            PreparedStatement ps=con.prepareStatement("delete from user905 where id=?");  
            ps.setInt(1,id);  
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception e){e.printStackTrace();}  
          
        return status;  
    }  
    public static Emp1 getEmployeeById(int id){  
        Emp1 e=new Emp1();  
          
        try{  
            Connection con=EmpDao1.getConnection();  
            PreparedStatement ps=con.prepareStatement("select * from user905 where id=?");  
            ps.setInt(1,id);  
            ResultSet rs=ps.executeQuery();  
            if(rs.next()){  
                e.setId(rs.getInt(1));  
                e.setName(rs.getString(2));  
                e.setAge(rs.getInt(3));  
                e.setSalary(rs.getInt(4));  
                e.setDesignation(rs.getString(5));  
            }  
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return e;  
    }  
    public static List<Emp1> getAllEmployees(){  
        List<Emp1> list=new ArrayList<Emp1>();  
          
        try{  
            Connection con=EmpDao1.getConnection();  
            PreparedStatement ps=con.prepareStatement("select * from user905");  
            ResultSet rs=ps.executeQuery();  
            while(rs.next()){  
                Emp1 e=new Emp1();  
                e.setId(rs.getInt(1));  
                e.setName(rs.getString(2));  
                e.setAge(rs.getInt(3));  
                e.setSalary(rs.getInt(4));  
                e.setDesignation(rs.getString(5));  
                list.add(e);  
            }  
            con.close();  
        }catch(Exception e){e.printStackTrace();}  
          
        return list;  
    }  

}


